function focoNacaixa(id, cor){
    document.getElementById(id).style.backgroundColor = cor;
  }

  function resetForm(){
    alert('O formulário foi redefinido!');
  }

  function showScreen(){
    alert('Seja bem vinde à tela de cadastro da Calamity Store!');
  }

  var nome = document.getElementById('nome').value; 