function focoNacaixa(id, cor){
    document.getElementById(id).style.backgroundColor = cor;
  }

  function resetForm(){
    alert('O formulário foi redefinido!');
  }

  function showScreen(){
    alert('Seja bem vinde à tela de cadastro da Calamity Store!');
  }

  function maiuscula(id){
    var nome = document.getElementById(id).value;
    document.getElementById(id).value = nome.toUpperCase(); 

  }

  function removerSobrenome(id){
    var nome = document.getElementById(id).value;
    var x;
    for( x = 0; x < nome.length-1; x++){
      if(nome.at(x) == ' '){
        resultado = document.getElementById(id).value = document.getElementById(id).value.substring(0, x);
      }
    }
  }

  function salvarDados(){
    var email = "Email: " + document.getElementById('email').value;
    var nome = "Nome: " + document.getElementById('nome').value;
    var cPf = "CPF: " + document.getElementById('cpf').value;
    var dtNascimento = "Data de Nascimento: " + document.getElementById('dtDnasc').value;
    var phone = "Telefone: " + document.getElementById('telefone').value;

    const dados = [email + "\n" + nome + "\n" + cPf + "\n" + dtNascimento + "\n" + phone];

    alert(dados);
  }

